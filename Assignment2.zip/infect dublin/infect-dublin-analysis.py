import networkx as nx
import numpy as np 
import matplotlib.pyplot as plt

def plot_degree_dist(G):
    degrees = [G.degree(n) for n in G.nodes()]
    plt.hist(degrees)
    plt.show()

floatSize = 3

with open('./infect-dublin.csv') as f:
    lines = f.readlines()

# creating graph
myList = [line.strip().split() for line in lines]
g = nx.Graph()
g.add_edges_from(myList)


# print nodes and edges (1)
print ('number of nodes: ', len(g.nodes()))
print ('number of edges: ', len(g.edges()))


# average degree
degrees = list(g.degree(g.nodes))
deg = list()
for d in degrees: 
    deg.append(d[1])
mean = np.mean(deg)
print('average degree: ', round(mean, floatSize))

# network density
density = nx.density(g)
print('network density: ', round(density, floatSize))

# network diameter
diameter = nx.diameter(g)
print('network diameter: ', round(diameter, floatSize))

# average clustering coefficient
clusteringCoefficient = nx.average_clustering(g)
print('average clustering coefficent: ', round(clusteringCoefficient, floatSize))

# transitivity
transitivity = nx.transitivity(g)
print('transitivity: ', round(transitivity, floatSize))

#average shortest path length
shortetstPathLength = nx.average_shortest_path_length(g)
print('shortest path average length: ', round(shortetstPathLength, 3))

# assortativity degree coefficent
assort =  nx.degree_assortativity_coefficient(g)
print('assortativity degree coefficent: ', round(assort, floatSize))

# 5 nodes with most degrees
sortedDegrees = sorted(g.degree, key=lambda x: x[1], reverse=True)
print('the nodes with most degrees: ', sortedDegrees[:5])

print()

bc = nx.betweenness_centrality(g)
sortedBC = {k: v for k, v in sorted(bc.items(), key=lambda item: item[1], reverse=True)}
listBC = [(k, v) for k, v in sortedBC.items()]
print('nodes with most betweenness centrality: ', listBC[:5])

print()

# seness centrality
cc = nx.closeness_centrality(g)
sortedCC = {k: v for k, v in sorted(cc.items(), key=lambda item: item[1], reverse=True)}
listCC = [(k, v) for k, v in sortedCC.items()]
print('nodes with most closeness centrality: ', listCC[:5])

print()

# page rank
pagerank = nx.pagerank(g, alpha= 0.85)
sortedPagerank = {k: v for k, v in sorted(pagerank.items(), key=lambda item: item[1], reverse=True)}
listPagerank = [(k, v) for k, v in sortedPagerank.items()]
print('nodes with most pagerank: ', listPagerank[:5])
